package com.example.log

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
