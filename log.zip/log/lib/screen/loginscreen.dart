import 'package:flutter/material.dart';
import 'package:log/screen/Homescreen.dart';

class Loginscreen extends StatefulWidget {
  const Loginscreen({super.key});

  @override
  State<Loginscreen> createState() => _LoginscreenState();
}

class _LoginscreenState extends State<Loginscreen> {
  final _username = TextEditingController();
  final _password = TextEditingController();
  String? _errormessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              TextFormField(
                controller: _username,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'USERNAME',
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              TextFormField(
                controller: _password,
                obscureText: true,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(), hintText: 'PASSWORD'),
              ),
              const SizedBox(
                height: 30,
              ),
              Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                ElevatedButton.icon(
                    onPressed: () {
                      login();
                    },
                    icon: const Icon(Icons.check),
                    label: Text('LOGIN'))
              ]),
              if (_errormessage != null)
                Text(
                  _errormessage!,
                  style: const TextStyle(color: Colors.red, fontSize: 14),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void login() {
    // Check if username or password is empty
    if (_username.text.isEmpty || _password.text.isEmpty) {
      setState(() {
        _errormessage = 'Username or Password cannot be empty';
      });
      return;
    }

    // Check if username and password match
    if (_username.text == _password.text) {
      // Navigate or perform success action
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Login successful')),
      );
      // Clear error message on success
      setState(() {
        _errormessage = null;
      });
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) =>
                Homescreen()), // The target screen to navigate to
      );
    } else {
      // Update the error message and refresh UI
      setState(() {
        _errormessage = 'Username and Password do not match';
      });
    }
  }
}
