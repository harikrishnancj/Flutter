package com.example.stud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
