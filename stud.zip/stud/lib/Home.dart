import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final _studentNameController = TextEditingController();
  final _ageController = TextEditingController();
  final _genderController = TextEditingController();

  // List to hold student details
  final List<Map<String, String>> _students = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            children: [
              TextFormField(
                controller: _studentNameController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'STUDENT NAME',
                ),
              ),
              const SizedBox(height: 30),
              TextFormField(
                controller: _ageController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'AGE',
                ),
              ),
              const SizedBox(height: 30),
              TextFormField(
                controller: _genderController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'GENDER',
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: addButtonClicked,
                label: const Text('ADD'),
                icon: const Icon(Icons.add),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: _students.isEmpty
                    ? const Center(child: Text('No students added yet!'))
                    : ListView.builder(
                        itemCount: _students.length,
                        itemBuilder: (context, index) {
                          final student = _students[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            child: ListTile(
                              title: Text('Name: ${student['name']}'),
                              subtitle: Text(
                                  'Age: ${student['age']}, Gender: ${student['gender']}'),
                              trailing: IconButton(
                                icon:
                                    const Icon(Icons.delete, color: Colors.red),
                                onPressed: () {
                                  deleteStudent(
                                      index); // Call the delete function
                                },
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void addButtonClicked() {
    final String name = _studentNameController.text.trim();
    final String age = _ageController.text.trim();
    final String gender = _genderController.text.trim();

    // Input validation
    if (name.isEmpty || age.isEmpty || gender.isEmpty) {
      // Show an error message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All fields are required!'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _students.add({'name': name, 'age': age, 'gender': gender});
    });

    // Clear the input fields
    _studentNameController.clear();
    _ageController.clear();
    _genderController.clear();
  }

  void deleteStudent(int index) {
    setState(() {
      _students.removeAt(index);
    });

    // Show a deletion confirmation
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Student deleted successfully!'),
        backgroundColor: Colors.green,
      ),
    );
  }
}
