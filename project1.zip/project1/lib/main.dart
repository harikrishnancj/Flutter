import 'package:flutter/material.dart'; // Importing Flutter Material package for Material Design components

// Main function - the entry point of the Flutter application
void main() {
  runApp(
      const MyApp1()); // Runs the application and sets MyApp1 as the root widget
}

// MyApp1 class - Root widget of the application
class MyApp1 extends StatelessWidget {
  const MyApp1({super.key}); // Constructor for the MyApp1 class

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // MaterialApp provides the structure for the application, including theming and navigation

      theme: ThemeData(
        // ThemeData defines the app's visual styling
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        // Generates a consistent color scheme based on a seed color (blue)

        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.blue,
          // Sets a global AppBar background color (blue) for the app
        ),
      ),
      home: const HomeScreen(),
      // Specifies the starting screen of the app. This is set to the HomeScreen widget
    );
  }
}

// HomeScreen class - Represents the main screen of the app
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key}); // Constructor for the HomeScreen class

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Scaffold provides the basic layout structure for a Material Design screen
      backgroundColor:
          Colors.white, // Sets the background color of the screen to white

      appBar: AppBar(
        // AppBar widget provides a top navigation bar for the screen
        title: const Text('Home Screen'), // Displays a title in the AppBar
      ),

      body: Container(
        width: double
            .infinity, // Makes the container span the entire width of the screen
        child: Center(
          child: Column(
            children: [
              Expanded(
                flex: 2, // Allocates 2 parts of available space to this section
                child: Center(
                  child: Text(
                    'App',
                    textAlign:
                        TextAlign.center, // Centers the text horizontally
                    style: TextStyle(
                      color: Colors.amber, // Text color
                      fontStyle: FontStyle.italic, // Italic font style
                      fontSize: 20, // Font size
                      fontWeight: FontWeight.bold, // Bold text weight
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 3, // Allocates 3 parts of available space to this section
                child: Row(
                  mainAxisAlignment: MainAxisAlignment
                      .center, // Aligns items horizontally at the center
                  children: [
                    TextButton(
                      onPressed: () {
                        print(
                            'TextButton clicked'); // Logs a message when clicked
                      },
                      child: Text('Click Me'), // Button label
                    ),
                    IconButton(
                      onPressed: () {
                        print(
                            'IconButton Pressed'); // Logs a message when clicked
                      },
                      icon: Icon(Icons.home), // Home icon for the button
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 1, // Allocates 1 part of available space to this section
                child: ElevatedButton(
                  onPressed: () {
                    print(
                        'ElevatedButton clicked'); // Logs a message when clicked
                  },
                  child: Text('Click Me'), // Button label
                ),
              ),
            ],
            
          ),
        ),
      ),
    );
  }
}
