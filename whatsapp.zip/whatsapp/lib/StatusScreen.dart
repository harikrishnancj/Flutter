import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Statusscreen extends StatelessWidget {
  const Statusscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('No active status',
        style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
    );
  }
}