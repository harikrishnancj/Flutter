import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Callsscreen extends StatefulWidget {
  const Callsscreen({super.key});

  @override
  State<Callsscreen> createState() => _CallsscreenState();
}

class _CallsscreenState extends State<Callsscreen> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'No Recent Calls',
        style: TextStyle(fontSize: 18, color: Colors.grey),
      ),
    );
  }
} 