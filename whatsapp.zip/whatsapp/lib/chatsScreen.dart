import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Chatsscreen extends StatefulWidget {
  const Chatsscreen({super.key});

  @override
  State<Chatsscreen> createState() => _ChatsscreenState();
}

class _ChatsscreenState extends State<Chatsscreen> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: (10),
        itemBuilder: (BuildContext context, int index) {
          return Column(
          children: [
            ListTile(
              leading: Icon(Icons.person),
              title: Text('Item #$index'), // Display the index of each item
              subtitle: Text('This is a list item'),
              onTap: () {
                print('Item $index tapped');
              },
            ),
            Divider(
              color: Colors.grey, // Set the color of the divider to grey
              thickness: 1,        // Set the thickness of the divider
              indent: 15,          // Set indentation for the divider (optional)
              endIndent: 15,       // Set end indentation (optional)
            ),
          ],
        );
      },
    );
  }
}