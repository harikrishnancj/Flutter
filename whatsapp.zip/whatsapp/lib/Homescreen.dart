import 'package:flutter/material.dart';
import 'package:whatsapp/CallsScreen.dart';
import 'package:whatsapp/StatusScreen.dart';
import 'package:whatsapp/chatsScreen.dart';

class Homescreen extends StatefulWidget {
  const Homescreen({super.key});

  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> {
  @override
  Widget build(BuildContext context) {
       return DefaultTabController(
      length: 3, // Number of tabs
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.teal,
          title: Text('WhatsApp'),
          actions: [
            Icon(Icons.search), // Search icon
            SizedBox(width: 10),
            Icon(Icons.more_vert), // Menu icon
          ],
          bottom: TabBar(
            indicatorColor: Colors.white, // Highlight color for the active tab
            tabs: [
              Tab(text: 'Chats'),
              Tab(text: 'Status'),
              Tab(text: 'Calls'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            Chatsscreen(),
           
            Statusscreen(),
             Callsscreen(), // Calls Tab
          ],
        ),
      ),
    );
  }
}