import 'package:flutter/material.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  final List<Map<String, String>> _expenses = [];
  final List<Map<String, String>> _incomes = [];

  void _addTransaction({required bool isExpense}) {
    final titleController = TextEditingController();
    final amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(isExpense ? 'Add Expense' : 'Add Income'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Amount'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final title = titleController.text.trim();
                final amount = amountController.text.trim();
                if (title.isNotEmpty && amount.isNotEmpty) {
                  setState(() {
                    if (isExpense) {
                      _expenses.add({'title': title, 'amount': '-\$${amount}'});
                    } else {
                      _incomes.add({'title': title, 'amount': '\$${amount}'});
                    }
                  });
                  Navigator.pop(context);
                }
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _deleteTransaction({required bool isExpense, required int index}) {
    setState(() {
      if (isExpense) {
        _expenses.removeAt(index);
      } else {
        _incomes.removeAt(index);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Category'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Expense'),
              Tab(text: 'Income'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ExpenseTab(
              expenses: _expenses,
              onAdd: () => _addTransaction(isExpense: true),
              onDelete: (index) => _deleteTransaction(isExpense: true, index: index),
            ),
            IncomeTab(
              incomes: _incomes,
              onAdd: () => _addTransaction(isExpense: false),
              onDelete: (index) => _deleteTransaction(isExpense: false, index: index),
            ),
          ],
        ),
      ),
    );
  }
}

class ExpenseTab extends StatelessWidget {
  final List<Map<String, String>> expenses;
  final VoidCallback onAdd;
  final Function(int) onDelete;

  const ExpenseTab({
    super.key,
    required this.expenses,
    required this.onAdd,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: onAdd,
          child: const Text('Add Expense'),
        ),
        Expanded(
          child: expenses.isEmpty
              ? const Center(
                  child: Text('No expenses added yet!', style: TextStyle(fontSize: 16)),
                )
              : ListView.builder(
                  itemCount: expenses.length,
                  itemBuilder: (context, index) {
                    final expense = expenses[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                      child: ListTile(
                        title: Text(expense['title'] ?? ''),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              expense['amount'] ?? '',
                              style: const TextStyle(color: Colors.red),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => onDelete(index),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class IncomeTab extends StatelessWidget {
  final List<Map<String, String>> incomes;
  final VoidCallback onAdd;
  final Function(int) onDelete;

  const IncomeTab({
    super.key,
    required this.incomes,
    required this.onAdd,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: onAdd,
          child: const Text('Add Income'),
        ),
        Expanded(
          child: incomes.isEmpty
              ? const Center(
                  child: Text('No incomes added yet!', style: TextStyle(fontSize: 16)),
                )
              : ListView.builder(
                  itemCount: incomes.length,
                  itemBuilder: (context, index) {
                    final income = incomes[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                      child: ListTile(
                        title: Text(income['title'] ?? ''),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              income['amount'] ?? '',
                              style: const TextStyle(color: Colors.green),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => onDelete(index),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
