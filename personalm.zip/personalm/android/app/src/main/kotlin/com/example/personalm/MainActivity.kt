package com.example.personalm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
