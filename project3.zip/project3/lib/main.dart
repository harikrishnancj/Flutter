import 'package:flutter/material.dart';
import 'package:project3/homescreen.dart';

void main() {
  runApp(demoapp());
}

class demoapp extends StatelessWidget {
  const demoapp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.white),
        appBarTheme: AppBarTheme(backgroundColor: Colors.blue),
      ),
      home: Homescreen(),
    );
  }
}
